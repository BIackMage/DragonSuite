#include <stdint.h>
#define crypto_uint64 uint64_t
