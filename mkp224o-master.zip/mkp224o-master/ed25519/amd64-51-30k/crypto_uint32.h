#include <stdint.h>
#define crypto_uint32 uint32_t
