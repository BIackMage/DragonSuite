#include <stdint.h>
#define crypto_int64 int64_t
